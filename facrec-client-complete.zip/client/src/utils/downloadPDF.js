// No PDF library is bundled with the client, so "download as PDF" opens a
// print-formatted window and lets the browser's native "Save as PDF"
// print destination do the work. Good enough for report exports without
// pulling in a heavy dependency.
export const downloadPDF = ({ title = "Report", columns = [], rows = [] }) => {
    const win = window.open("", "_blank", "width=900,height=700");
    if (!win) return;

    const head = columns.map((c) => `<th>${c.label}</th>`).join("");
    const body = rows
        .map((row) => {
            const cells = columns
                .map((c) => `<td>${row[c.key] ?? ""}</td>`)
                .join("");
            return `<tr>${cells}</tr>`;
        })
        .join("");

    win.document.write(`
        <html>
            <head>
                <title>${title}</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
                    h1 { font-size: 18px; margin-bottom: 4px; }
                    p { color: #555; margin-top: 0; font-size: 12px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
                    th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 12px; text-align: left; }
                    th { background: #f2f2f2; }
                </style>
            </head>
            <body>
                <h1>${title}</h1>
                <p>Generated on ${new Date().toLocaleString("en-IN")}</p>
                <table>
                    <thead><tr>${head}</tr></thead>
                    <tbody>${body}</tbody>
                </table>
            </body>
        </html>
    `);
    win.document.close();
    win.focus();
    win.print();
};

// Bonus: plain CSV export, useful alongside the PDF helper for raw data.
export const downloadCSV = ({ filename = "export.csv", columns = [], rows = [] }) => {
    const header = columns.map((c) => `"${c.label}"`).join(",");
    const body = rows
        .map((row) =>
            columns.map((c) => `"${String(row[c.key] ?? "").replace(/"/g, '""')}"`).join(",")
        )
        .join("\n");

    const csv = `${header}\n${body}`;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
};

export default downloadPDF;
