const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const validateEmail = (email = "") => EMAIL_REGEX.test(email.trim());

export default validateEmail;
