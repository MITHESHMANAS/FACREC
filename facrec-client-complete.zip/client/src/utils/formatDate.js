// Formats an ISO date / date string into "12 Jul 2026".
// Falls back to the raw value if it isn't a parseable date.
export const formatDate = (value, options) => {
    if (!value) return "—";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        ...options,
    });
};

export default formatDate;
