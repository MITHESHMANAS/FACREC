// Sessions store startTime/endTime as plain "HH:MM" strings, and
// timestamps come back as ISO strings. Handle both.
export const formatTime = (value) => {
    if (!value) return "—";

    // Plain "HH:MM" or "HH:MM:SS" string
    if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(value)) {
        const [h, m] = value.split(":");
        const hour = Number(h);
        const suffix = hour >= 12 ? "PM" : "AM";
        const hour12 = hour % 12 === 0 ? 12 : hour % 12;
        return `${hour12}:${m} ${suffix}`;
    }

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
    });
};

export default formatTime;
