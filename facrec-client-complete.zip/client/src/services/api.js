import axios from "axios";

// Base URL comes from the Vite env so it's easy to point at a different
// backend in dev/staging/prod without touching code.
// Create client/.env with: VITE_API_URL=http://localhost:5000
const baseURL = import.meta.env.VITE_API_URL || "http://localhost:5000";

const api = axios.create({
    baseURL,
    headers: {
        "Content-Type": "application/json",
    },
});

// Attach the JWT (if we have one) to every outgoing request.
api.interceptors.request.use((config) => {
    const token = localStorage.getItem("facrec_token");
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// If the token is invalid/expired, boot the user back to /login instead of
// letting every page handle 401s individually.
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem("facrec_token");
            localStorage.removeItem("facrec_user");
            if (window.location.pathname !== "/login") {
                window.location.href = "/login";
            }
        }
        return Promise.reject(error);
    }
);

export default api;
