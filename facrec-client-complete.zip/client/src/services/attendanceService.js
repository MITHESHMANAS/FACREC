import api from "./api";
import { API } from "../api/endpoints";

export const getAttendance = async () => {
    const { data } = await api.get(API.ATTENDANCE);
    return data.attendance || [];
};

export const markAttendance = async (payload) => {
    // payload: { student, session, status }
    const { data } = await api.post(API.ATTENDANCE, payload);
    return data.attendance;
};

export default { getAttendance, markAttendance };
