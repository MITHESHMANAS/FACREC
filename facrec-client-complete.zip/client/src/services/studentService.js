import api from "./api";
import { API } from "../api/endpoints";

export const getStudents = async () => {
    const { data } = await api.get(API.STUDENTS);
    return data.students || [];
};

export const getStudentById = async (id) => {
    const { data } = await api.get(API.STUDENT_BY_ID(id));
    return data.student;
};

export const createStudent = async (payload) => {
    const { data } = await api.post(API.STUDENTS, payload);
    return data.student;
};

export const updateStudent = async (id, payload) => {
    const { data } = await api.put(API.STUDENT_BY_ID(id), payload);
    return data.student;
};

export const deleteStudent = async (id) => {
    const { data } = await api.delete(API.STUDENT_BY_ID(id));
    return data;
};

export default {
    getStudents,
    getStudentById,
    createStudent,
    updateStudent,
    deleteStudent,
};
