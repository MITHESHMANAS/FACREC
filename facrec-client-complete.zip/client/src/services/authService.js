import api from "./api";
import { API } from "../api/endpoints";

export const login = async (email, password) => {
    const { data } = await api.post(API.LOGIN, { email, password });
    return data; // { success, message, token, user }
};

export const register = async (payload) => {
    // payload: { name, email, password, role }
    const { data } = await api.post(API.REGISTER, payload);
    return data;
};

export default { login, register };
