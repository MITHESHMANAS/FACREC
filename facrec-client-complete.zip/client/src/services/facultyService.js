import api from "./api";
import { API } from "../api/endpoints";

export const getFaculty = async () => {
    const { data } = await api.get(API.FACULTY);
    return data.faculty || [];
};

export const createFaculty = async (payload) => {
    const { data } = await api.post(API.FACULTY, payload);
    return data.faculty;
};

export default { getFaculty, createFaculty };
