import api from "./api";
import { API } from "../api/endpoints";

export const getSessions = async () => {
    const { data } = await api.get(API.SESSIONS);
    return data.sessions || [];
};

export const createSession = async (payload) => {
    const { data } = await api.post(API.SESSIONS, payload);
    return data.session;
};

export default { getSessions, createSession };
