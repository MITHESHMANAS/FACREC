import api from "./api";
import { API } from "../api/endpoints";

export const getSubjects = async () => {
    const { data } = await api.get(API.SUBJECTS);
    return data.subjects || [];
};

export const createSubject = async (payload) => {
    const { data } = await api.post(API.SUBJECTS, payload);
    return data.subject;
};

export default { getSubjects, createSubject };
