import { useCallback, useState } from "react";
import useFetch from "./useFetch";
import * as attendanceService from "../services/attendanceService";

// Combines the attendance list fetch with a "mark attendance" action that
// optimistically appends to local state, so the Attendance page doesn't
// need to juggle both itself.
const useAttendance = () => {
    const { data, loading, error, refetch, setData } = useFetch(
        attendanceService.getAttendance,
        []
    );
    const [marking, setMarking] = useState(false);
    const [markError, setMarkError] = useState(null);

    const mark = useCallback(
        async (payload) => {
            setMarking(true);
            setMarkError(null);
            try {
                const record = await attendanceService.markAttendance(payload);
                setData((prev) => [record, ...(prev || [])]);
                return record;
            } catch (err) {
                setMarkError(err?.response?.data?.message || err.message || "Could not mark attendance");
                throw err;
            } finally {
                setMarking(false);
            }
        },
        [setData]
    );

    return {
        attendance: data || [],
        loading,
        error,
        refetch,
        mark,
        marking,
        markError,
    };
};

export default useAttendance;
