import { useCallback, useState } from "react";
import api from "../services/api";

// For one-off imperative calls (form submits, button actions) where you
// want loading/error state without writing it out every time.
//
// const { request, loading, error } = useAxios();
// const submit = () => request({ method: "post", url: API.STUDENTS, data });
const useAxios = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const request = useCallback(async (config) => {
        setLoading(true);
        setError(null);
        try {
            const response = await api.request(config);
            return response.data;
        } catch (err) {
            const message = err?.response?.data?.message || err.message || "Request failed";
            setError(message);
            throw err;
        } finally {
            setLoading(false);
        }
    }, []);

    return { request, loading, error };
};

export default useAxios;
