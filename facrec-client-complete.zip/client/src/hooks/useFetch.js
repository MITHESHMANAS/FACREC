import { useEffect, useState } from "react";

// Wraps any async fetcher function with loading / error / data state and
// a manual refetch, so pages don't repeat the same boilerplate.
//
// const { data, loading, error, refetch } = useFetch(getStudents);
const useFetch = (fetcher) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [reloadToken, setReloadToken] = useState(0);

    useEffect(() => {
        let mounted = true;

        const run = async () => {
            setLoading(true);
            setError(null);
            try {
                const result = await fetcher();
                if (mounted) setData(result);
            } catch (err) {
                if (mounted) {
                    setError(err?.response?.data?.message || err.message || "Something went wrong");
                }
            } finally {
                if (mounted) setLoading(false);
            }
        };

        run();
        return () => {
            mounted = false;
        };
        // fetcher is expected to be stable (module-level service function);
        // reloadToken is the only thing that should re-trigger this effect.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [reloadToken]);

    const refetch = () => setReloadToken((t) => t + 1);

    return { data, loading, error, refetch, setData };
};

export default useFetch;
