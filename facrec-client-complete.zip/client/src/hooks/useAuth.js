import { useAuthContext } from "../context/AuthContext";

// Anywhere in the app: const { user, role, login, logout } = useAuth();
const useAuth = () => useAuthContext();

export default useAuth;
