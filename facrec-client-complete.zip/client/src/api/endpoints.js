// Centralized API endpoint constants.
// Keep every route the frontend calls in one place so nothing is hardcoded
// inline in components/services.

export const API = {
    // Auth
    LOGIN: "/api/auth/login",
    REGISTER: "/api/auth/register",

    // Students
    STUDENTS: "/api/students",
    STUDENT_BY_ID: (id) => `/api/students/${id}`,

    // Subjects
    SUBJECTS: "/api/subjects",

    // Faculty
    FACULTY: "/api/faculty",

    // Sessions
    SESSIONS: "/api/sessions",

    // Attendance
    ATTENDANCE: "/api/attendance",

    // Dashboard (no dedicated backend route yet — the Dashboard page
    // derives its stats from the endpoints above)
    DASHBOARD: "/api/dashboard",
};

export default API;
