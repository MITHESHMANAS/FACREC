const VARIANTS = {
    primary:
        "bg-[var(--color-accent)] text-white hover:brightness-110 disabled:opacity-50",
    secondary:
        "bg-transparent border border-[var(--color-border)] text-[var(--color-text)] hover:border-[var(--color-accent)] disabled:opacity-50",
    danger:
        "bg-[var(--color-danger)]/10 border border-[var(--color-danger)]/40 text-[var(--color-danger)] hover:bg-[var(--color-danger)]/20 disabled:opacity-50",
    ghost:
        "bg-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)] disabled:opacity-50",
};

const Button = ({
    children,
    variant = "primary",
    type = "button",
    loading = false,
    disabled = false,
    className = "",
    onClick,
    ...rest
}) => {
    return (
        <button
            type={type}
            onClick={onClick}
            disabled={disabled || loading}
            className={`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors cursor-pointer disabled:cursor-not-allowed ${VARIANTS[variant]} ${className}`}
            {...rest}
        >
            {loading && (
                <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
            )}
            {children}
        </button>
    );
};

export default Button;
