// icon: any emoji / rendered element. trend: optional { value, positive }
const StatCard = ({ icon, label, value, trend, accent = "var(--color-accent)" }) => {
    return (
        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
            <div className="flex items-start justify-between">
                <div>
                    <p className="text-xs uppercase tracking-wide text-[var(--color-text-muted)]">
                        {label}
                    </p>
                    <p className="mt-2 text-2xl font-semibold text-[var(--color-text)]">
                        {value}
                    </p>
                </div>
                {icon && (
                    <div
                        className="flex h-10 w-10 items-center justify-center rounded-xl text-lg"
                        style={{ background: `${accent}22`, color: accent }}
                    >
                        {icon}
                    </div>
                )}
            </div>
            {trend && (
                <p
                    className={`mt-3 text-xs font-medium ${
                        trend.positive ? "text-[var(--color-success)]" : "text-[var(--color-danger)]"
                    }`}
                >
                    {trend.positive ? "▲" : "▼"} {trend.value}
                </p>
            )}
        </div>
    );
};

export default StatCard;
