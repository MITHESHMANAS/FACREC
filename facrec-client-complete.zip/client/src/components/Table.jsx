import Loader from "./Loader";

// columns: [{ key, label, render? }]
// data: array of row objects
const Table = ({ columns = [], data = [], loading = false, emptyMessage = "No records found." }) => {
    if (loading) {
        return (
            <div className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] p-10">
                <Loader label="Loading data…" />
            </div>
        );
    }

    if (!data.length) {
        return (
            <div className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] p-10 text-center text-sm text-[var(--color-text-muted)]">
                {emptyMessage}
            </div>
        );
    }

    return (
        <div className="overflow-x-auto rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)]">
            <table className="w-full min-w-[600px] border-collapse text-sm">
                <thead>
                    <tr className="border-b border-[var(--color-border)] text-left text-xs uppercase tracking-wide text-[var(--color-text-muted)]">
                        {columns.map((col) => (
                            <th key={col.key} className="px-4 py-3 font-medium">
                                {col.label}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, idx) => (
                        <tr
                            key={row._id || row.id || idx}
                            className="border-b border-[var(--color-border)] last:border-0 hover:bg-white/5"
                        >
                            {columns.map((col) => (
                                <td key={col.key} className="px-4 py-3 text-[var(--color-text)]">
                                    {col.render ? col.render(row) : row[col.key] ?? "—"}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Table;
