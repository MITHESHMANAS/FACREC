const Loader = ({ label = "Loading…", size = "md", full = false }) => {
    const sizes = { sm: "h-4 w-4 border-2", md: "h-6 w-6 border-2", lg: "h-10 w-10 border-4" };

    const spinner = (
        <div className="flex flex-col items-center justify-center gap-3 text-[var(--color-text-muted)]">
            <div
                className={`${sizes[size]} animate-spin rounded-full border-[var(--color-border)] border-t-[var(--color-accent)]`}
            />
            {label && <span className="text-sm">{label}</span>}
        </div>
    );

    if (full) {
        return <div className="flex min-h-[240px] w-full items-center justify-center">{spinner}</div>;
    }

    return spinner;
};

export default Loader;
