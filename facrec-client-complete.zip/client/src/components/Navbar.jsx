import useAuth from "../hooks/useAuth";
import { capitalize } from "../utils/capitalize";

const Navbar = ({ title = "FACREC" }) => {
    const { user, logout } = useAuth();

    const initials = (user?.name || "?")
        .split(" ")
        .map((p) => p[0])
        .slice(0, 2)
        .join("")
        .toUpperCase();

    return (
        <header className="flex h-16 items-center justify-between border-b border-[var(--color-border)] bg-[var(--color-bg-soft)] px-6">
            <h1 className="text-base font-semibold text-[var(--color-text)]">{title}</h1>

            <div className="flex items-center gap-4">
                <div className="text-right">
                    <p className="text-sm font-medium text-[var(--color-text)]">{user?.name}</p>
                    <p className="text-xs text-[var(--color-text-muted)]">{capitalize(user?.role)}</p>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--color-accent-soft)] text-sm font-semibold text-[var(--color-accent)]">
                    {initials}
                </div>
                <button
                    onClick={logout}
                    className="rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-xs font-medium text-[var(--color-text-muted)] hover:border-[var(--color-danger)] hover:text-[var(--color-danger)] cursor-pointer"
                >
                    Logout
                </button>
            </div>
        </header>
    );
};

export default Navbar;
