import { NavLink } from "react-router-dom";
import useAuth from "../hooks/useAuth";

const NAV_ITEMS = [
    { to: "/dashboard", label: "Dashboard", icon: "🏠", roles: ["admin", "faculty", "student"] },
    { to: "/students", label: "Students", icon: "🎓", roles: ["admin", "faculty"] },
    { to: "/subjects", label: "Subjects", icon: "📚", roles: ["admin", "faculty"] },
    { to: "/faculty", label: "Faculty", icon: "🧑‍🏫", roles: ["admin"] },
    { to: "/sessions", label: "Sessions", icon: "🗓️", roles: ["admin", "faculty"] },
    { to: "/attendance", label: "Attendance", icon: "✅", roles: ["admin", "faculty"] },
    { to: "/analytics", label: "Analytics", icon: "📊", roles: ["admin", "faculty"] },
];

const Sidebar = () => {
    const { role } = useAuth();
    const items = NAV_ITEMS.filter((item) => item.roles.includes(role));

    return (
        <aside className="flex h-full w-60 flex-col border-r border-[var(--color-border)] bg-[var(--color-bg-soft)]">
            <div className="flex items-center gap-2 px-6 py-5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--color-accent)] text-sm font-bold text-white">
                    F
                </div>
                <span className="text-lg font-semibold text-[var(--color-text)]">FACREC</span>
            </div>

            <nav className="flex-1 space-y-1 px-3">
                {items.map((item) => (
                    <NavLink
                        key={item.to}
                        to={item.to}
                        className={({ isActive }) =>
                            `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                                isActive
                                    ? "bg-[var(--color-accent-soft)] text-[var(--color-accent)]"
                                    : "text-[var(--color-text-muted)] hover:bg-white/5 hover:text-[var(--color-text)]"
                            }`
                        }
                    >
                        <span>{item.icon}</span>
                        {item.label}
                    </NavLink>
                ))}
            </nav>

            <div className="border-t border-[var(--color-border)] px-6 py-4 text-xs text-[var(--color-text-muted)]">
                FACREC Enterprise v1.0
            </div>
        </aside>
    );
};

export default Sidebar;
