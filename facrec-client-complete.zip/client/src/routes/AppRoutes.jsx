import { Navigate, Route, Routes } from "react-router-dom";
import ProtectedRoute from "../components/ProtectedRoute";
import AdminLayout from "../layouts/AdminLayout";
import FacultyLayout from "../layouts/FacultyLayout";
import StudentLayout from "../layouts/StudentLayout";
import useAuth from "../hooks/useAuth";

import Login from "../pages/Login";
import Dashboard from "../pages/Dashboard";
import Students from "../pages/Students";
import Subjects from "../pages/Subjects";
import Faculty from "../pages/Faculty";
import Sessions from "../pages/Sessions";
import Attendance from "../pages/Attendance";
import Analytics from "../pages/Analytics";

// Picks the right chrome (sidebar+navbar vs plain navbar) based on the
// logged-in user's role, without needing separate route trees per role.
const RoleLayout = () => {
    const { role } = useAuth();
    if (role === "student") return <StudentLayout />;
    if (role === "faculty") return <FacultyLayout />;
    return <AdminLayout />;
};

const AppRoutes = () => {
    return (
        <Routes>
            <Route path="/login" element={<Login />} />

            <Route element={<ProtectedRoute />}>
                <Route element={<RoleLayout />}>
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/analytics" element={<Analytics />} />

                    <Route element={<ProtectedRoute roles={["admin", "faculty"]} />}>
                        <Route path="/students" element={<Students />} />
                        <Route path="/subjects" element={<Subjects />} />
                        <Route path="/sessions" element={<Sessions />} />
                        <Route path="/attendance" element={<Attendance />} />
                    </Route>

                    <Route element={<ProtectedRoute roles={["admin"]} />}>
                        <Route path="/faculty" element={<Faculty />} />
                    </Route>
                </Route>
            </Route>

            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
    );
};

export default AppRoutes;
