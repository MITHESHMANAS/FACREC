import { Outlet } from "react-router-dom";
import Navbar from "../components/Navbar";

const StudentLayout = () => {
    return (
        <div className="flex h-screen w-full flex-col overflow-hidden">
            <Navbar title="Student Portal" />
            <main className="flex-1 overflow-y-auto bg-[var(--color-bg)] p-6">
                <div className="mx-auto max-w-4xl">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default StudentLayout;
