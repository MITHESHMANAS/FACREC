import { Outlet } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

const AdminLayout = () => {
    return (
        <div className="flex h-screen w-full overflow-hidden">
            <Sidebar />
            <div className="flex flex-1 flex-col overflow-hidden">
                <Navbar title="Admin Console" />
                <main className="flex-1 overflow-y-auto bg-[var(--color-bg)] p-6">
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

export default AdminLayout;
