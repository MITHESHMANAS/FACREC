import { useState } from "react";
import useFetch from "../hooks/useFetch";
import * as facultyService from "../services/facultyService";
import Table from "../components/Table";
import Button from "../components/Button";
import Modal from "../components/Modal";

const EMPTY_FORM = { name: "", email: "", employeeId: "", department: "", designation: "Assistant Professor" };

const Faculty = () => {
    const { data: faculty, loading, error, setData } = useFetch(facultyService.getFaculty, []);

    const [modalOpen, setModalOpen] = useState(false);
    const [form, setForm] = useState(EMPTY_FORM);
    const [formError, setFormError] = useState("");
    const [submitting, setSubmitting] = useState(false);

    const onSubmit = async (e) => {
        e.preventDefault();
        setFormError("");
        setSubmitting(true);
        try {
            const created = await facultyService.createFaculty(form);
            setData((prev) => [created, ...(prev || [])]);
            setModalOpen(false);
            setForm(EMPTY_FORM);
        } catch (err) {
            setFormError(err?.response?.data?.message || "Could not save faculty member.");
        } finally {
            setSubmitting(false);
        }
    };

    const columns = [
        { key: "employeeId", label: "Employee ID" },
        { key: "name", label: "Name" },
        { key: "email", label: "Email" },
        { key: "department", label: "Department" },
        { key: "designation", label: "Designation" },
        {
            key: "isActive",
            label: "Status",
            render: (row) => (
                <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        row.isActive
                            ? "bg-[var(--color-success)]/15 text-[var(--color-success)]"
                            : "bg-white/10 text-[var(--color-text-muted)]"
                    }`}
                >
                    {row.isActive ? "Active" : "Inactive"}
                </span>
            ),
        },
    ];

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <h2 className="text-xl font-semibold text-[var(--color-text)]">Faculty</h2>
                    <p className="text-sm text-[var(--color-text-muted)]">
                        {faculty?.length ?? 0} faculty members
                    </p>
                </div>
                <Button onClick={() => setModalOpen(true)}>+ Add Faculty</Button>
            </div>

            {error && (
                <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                    {error}
                </p>
            )}

            <Table columns={columns} data={faculty || []} loading={loading} emptyMessage="No faculty members found." />

            <Modal
                open={modalOpen}
                onClose={() => setModalOpen(false)}
                title="Add Faculty"
                footer={
                    <>
                        <Button variant="secondary" onClick={() => setModalOpen(false)}>
                            Cancel
                        </Button>
                        <Button onClick={onSubmit} loading={submitting}>
                            Add Faculty
                        </Button>
                    </>
                }
            >
                <form onSubmit={onSubmit} className="space-y-3">
                    <Field label="Full Name">
                        <input
                            required
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <Field label="Email">
                        <input
                            type="email"
                            required
                            value={form.email}
                            onChange={(e) => setForm({ ...form, email: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <div className="grid grid-cols-2 gap-3">
                        <Field label="Employee ID">
                            <input
                                required
                                value={form.employeeId}
                                onChange={(e) => setForm({ ...form, employeeId: e.target.value })}
                                className="input"
                            />
                        </Field>
                        <Field label="Department">
                            <input
                                required
                                value={form.department}
                                onChange={(e) => setForm({ ...form, department: e.target.value })}
                                className="input"
                            />
                        </Field>
                    </div>
                    <Field label="Designation">
                        <input
                            value={form.designation}
                            onChange={(e) => setForm({ ...form, designation: e.target.value })}
                            className="input"
                        />
                    </Field>
                    {formError && (
                        <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                            {formError}
                        </p>
                    )}
                </form>
            </Modal>
        </div>
    );
};

const Field = ({ label, children }) => (
    <div>
        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">{label}</label>
        {children}
    </div>
);

export default Faculty;
