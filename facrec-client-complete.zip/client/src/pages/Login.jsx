import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import useAuth from "../hooks/useAuth";
import { validateEmail } from "../utils/validateEmail";
import Button from "../components/Button";

const Login = () => {
    const { login, register } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const redirectTo = location.state?.from?.pathname || "/dashboard";

    const [mode, setMode] = useState("login"); // "login" | "register"
    const [form, setForm] = useState({ name: "", email: "", password: "", role: "student" });
    const [error, setError] = useState("");
    const [submitting, setSubmitting] = useState(false);

    const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

    const onSubmit = async (e) => {
        e.preventDefault();
        setError("");

        if (!validateEmail(form.email)) {
            setError("Enter a valid email address.");
            return;
        }
        if (form.password.length < 6) {
            setError("Password must be at least 6 characters.");
            return;
        }

        setSubmitting(true);
        try {
            if (mode === "login") {
                await login(form.email, form.password);
            } else {
                await register(form);
            }
            navigate(redirectTo, { replace: true });
        } catch (err) {
            setError(err?.response?.data?.message || "Something went wrong. Please try again.");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="flex min-h-screen w-full items-center justify-center bg-[var(--color-bg)] px-4">
            <div className="w-full max-w-md rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-8 shadow-2xl">
                <div className="mb-6 text-center">
                    <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--color-accent)] text-xl font-bold text-white">
                        F
                    </div>
                    <h1 className="text-xl font-semibold text-[var(--color-text)]">FACREC Enterprise</h1>
                    <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                        Facial recognition attendance, made simple.
                    </p>
                </div>

                <div className="mb-6 flex rounded-lg border border-[var(--color-border)] p-1 text-sm">
                    <button
                        type="button"
                        onClick={() => setMode("login")}
                        className={`flex-1 rounded-md py-1.5 font-medium cursor-pointer ${
                            mode === "login" ? "bg-[var(--color-accent)] text-white" : "text-[var(--color-text-muted)]"
                        }`}
                    >
                        Sign in
                    </button>
                    <button
                        type="button"
                        onClick={() => setMode("register")}
                        className={`flex-1 rounded-md py-1.5 font-medium cursor-pointer ${
                            mode === "register" ? "bg-[var(--color-accent)] text-white" : "text-[var(--color-text-muted)]"
                        }`}
                    >
                        Create account
                    </button>
                </div>

                <form onSubmit={onSubmit} className="space-y-4">
                    {mode === "register" && (
                        <div>
                            <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
                                Full name
                            </label>
                            <input
                                name="name"
                                value={form.name}
                                onChange={onChange}
                                required
                                className="w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-bg)] px-3 py-2 text-sm text-[var(--color-text)] outline-none focus:border-[var(--color-accent)]"
                                placeholder="Jane Doe"
                            />
                        </div>
                    )}

                    <div>
                        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
                            Email
                        </label>
                        <input
                            type="email"
                            name="email"
                            value={form.email}
                            onChange={onChange}
                            required
                            className="w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-bg)] px-3 py-2 text-sm text-[var(--color-text)] outline-none focus:border-[var(--color-accent)]"
                            placeholder="you@college.edu"
                        />
                    </div>

                    <div>
                        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
                            Password
                        </label>
                        <input
                            type="password"
                            name="password"
                            value={form.password}
                            onChange={onChange}
                            required
                            className="w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-bg)] px-3 py-2 text-sm text-[var(--color-text)] outline-none focus:border-[var(--color-accent)]"
                            placeholder="••••••••"
                        />
                    </div>

                    {mode === "register" && (
                        <div>
                            <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
                                Role
                            </label>
                            <select
                                name="role"
                                value={form.role}
                                onChange={onChange}
                                className="w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-bg)] px-3 py-2 text-sm text-[var(--color-text)] outline-none focus:border-[var(--color-accent)]"
                            >
                                <option value="student">Student</option>
                                <option value="faculty">Faculty</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                    )}

                    {error && (
                        <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                            {error}
                        </p>
                    )}

                    <Button type="submit" loading={submitting} className="w-full">
                        {mode === "login" ? "Sign in" : "Create account"}
                    </Button>
                </form>
            </div>
        </div>
    );
};

export default Login;
