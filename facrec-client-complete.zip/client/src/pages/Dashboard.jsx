import { useEffect, useState } from "react";
import StatCard from "../components/StatCard";
import Table from "../components/Table";
import Loader from "../components/Loader";
import useAuth from "../hooks/useAuth";
import { getStudents } from "../services/studentService";
import { getSubjects } from "../services/subjectService";
import { getFaculty } from "../services/facultyService";
import { getSessions } from "../services/sessionService";
import { getAttendance } from "../services/attendanceService";
import { formatDate } from "../utils/formatDate";
import { formatTime } from "../utils/formatTime";

const Dashboard = () => {
    const { user, role } = useAuth();
    const [stats, setStats] = useState(null);
    const [sessions, setSessions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        let mounted = true;

        const load = async () => {
            setLoading(true);
            setError("");
            try {
                // Students/Faculty require admin or faculty on the backend, so a
                // "student" role account will get 403s here — that's expected;
                // we just fall back to zeros for anything that fails.
                const results = await Promise.allSettled([
                    getStudents(),
                    getSubjects(),
                    getFaculty(),
                    getSessions(),
                    getAttendance(),
                ]);

                if (!mounted) return;

                const [students, subjects, faculty, sessionsRes, attendance] = results.map((r) =>
                    r.status === "fulfilled" ? r.value : []
                );

                const activeSessions = sessionsRes.filter((s) => s.status === "ACTIVE").length;

                setStats({
                    students: students.length,
                    subjects: subjects.length,
                    faculty: faculty.length,
                    sessions: sessionsRes.length,
                    activeSessions,
                    attendance: attendance.length,
                });
                setSessions(
                    [...sessionsRes]
                        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                        .slice(0, 6)
                );
            } catch {
                if (mounted) setError("Could not load dashboard data.");
            } finally {
                if (mounted) setLoading(false);
            }
        };

        load();
        return () => {
            mounted = false;
        };
    }, []);

    const columns = [
        { key: "subject", label: "Subject", render: (row) => row.subject?.name || row.subject?.code || "—" },
        { key: "faculty", label: "Faculty" },
        { key: "branch", label: "Branch" },
        { key: "date", label: "Date", render: (row) => formatDate(row.date) },
        { key: "startTime", label: "Start", render: (row) => formatTime(row.startTime) },
        {
            key: "status",
            label: "Status",
            render: (row) => (
                <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        row.status === "ACTIVE"
                            ? "bg-[var(--color-success)]/15 text-[var(--color-success)]"
                            : "bg-white/10 text-[var(--color-text-muted)]"
                    }`}
                >
                    {row.status}
                </span>
            ),
        },
    ];

    if (loading) return <Loader full label="Loading dashboard…" />;

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold text-[var(--color-text)]">
                    Welcome back, {user?.name?.split(" ")[0] || "there"} 👋
                </h2>
                <p className="text-sm text-[var(--color-text-muted)]">
                    Here's what's happening across the institution today.
                </p>
            </div>

            {error && (
                <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                    {error}
                </p>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
                <StatCard icon="🎓" label="Students" value={stats?.students ?? 0} />
                <StatCard icon="📚" label="Subjects" value={stats?.subjects ?? 0} accent="var(--color-cyan)" />
                <StatCard icon="🧑‍🏫" label="Faculty" value={stats?.faculty ?? 0} accent="var(--color-warning)" />
                <StatCard
                    icon="🗓️"
                    label="Active Sessions"
                    value={stats?.activeSessions ?? 0}
                    accent="var(--color-success)"
                />
                <StatCard icon="✅" label="Attendance Records" value={stats?.attendance ?? 0} />
            </div>

            <div>
                <h3 className="mb-3 text-sm font-semibold text-[var(--color-text)]">Recent Sessions</h3>
                <Table columns={columns} data={sessions} emptyMessage="No sessions have been created yet." />
            </div>

            {role === "student" && !stats?.students && (
                <p className="text-xs text-[var(--color-text-muted)]">
                    Some stats are hidden — student accounts don't have access to the admin/faculty data
                    endpoints on the backend.
                </p>
            )}
        </div>
    );
};

export default Dashboard;
