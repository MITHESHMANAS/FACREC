import { useMemo } from "react";
import useFetch from "../hooks/useFetch";
import * as attendanceService from "../services/attendanceService";
import * as sessionService from "../services/sessionService";
import * as studentService from "../services/studentService";
import Loader from "../components/Loader";
import StatCard from "../components/StatCard";

const Analytics = () => {
    const { data: attendance, loading: l1 } = useFetch(attendanceService.getAttendance, []);
    const { data: sessions, loading: l2 } = useFetch(sessionService.getSessions, []);
    const { data: students, loading: l3 } = useFetch(studentService.getStudents, []);

    const loading = l1 || l2 || l3;

    const bySubject = useMemo(() => {
        if (!attendance) return [];
        const map = new Map();
        attendance.forEach((row) => {
            const key = row.session?.subject?.name || row.session?.subject?.code || "Unassigned";
            const entry = map.get(key) || { subject: key, present: 0, total: 0 };
            entry.total += 1;
            if (row.status === "Present") entry.present += 1;
            map.set(key, entry);
        });
        return Array.from(map.values())
            .map((e) => ({ ...e, pct: e.total ? Math.round((e.present / e.total) * 100) : 0 }))
            .sort((a, b) => b.pct - a.pct);
    }, [attendance]);

    const overallPct = useMemo(() => {
        if (!attendance?.length) return 0;
        const present = attendance.filter((a) => a.status === "Present").length;
        return Math.round((present / attendance.length) * 100);
    }, [attendance]);

    if (loading) return <Loader full label="Crunching the numbers…" />;

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold text-[var(--color-text)]">Analytics</h2>
                <p className="text-sm text-[var(--color-text-muted)]">
                    Attendance trends derived from live session and attendance records.
                </p>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <StatCard icon="📈" label="Overall Attendance" value={`${overallPct}%`} />
                <StatCard icon="🗓️" label="Total Sessions" value={sessions?.length ?? 0} accent="var(--color-cyan)" />
                <StatCard icon="🎓" label="Total Students" value={students?.length ?? 0} accent="var(--color-warning)" />
            </div>

            <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
                <h3 className="mb-4 text-sm font-semibold text-[var(--color-text)]">
                    Attendance Rate by Subject
                </h3>

                {bySubject.length === 0 ? (
                    <p className="text-sm text-[var(--color-text-muted)]">
                        No attendance data yet — mark some attendance to see trends here.
                    </p>
                ) : (
                    <div className="space-y-4">
                        {bySubject.map((row) => (
                            <div key={row.subject}>
                                <div className="mb-1 flex items-center justify-between text-xs">
                                    <span className="font-medium text-[var(--color-text)]">{row.subject}</span>
                                    <span className="text-[var(--color-text-muted)]">
                                        {row.present}/{row.total} · {row.pct}%
                                    </span>
                                </div>
                                <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
                                    <div
                                        className="h-full rounded-full bg-[var(--color-accent)]"
                                        style={{ width: `${row.pct}%` }}
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Analytics;
