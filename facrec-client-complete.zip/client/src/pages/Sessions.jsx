import { useState } from "react";
import useFetch from "../hooks/useFetch";
import * as sessionService from "../services/sessionService";
import * as subjectService from "../services/subjectService";
import Table from "../components/Table";
import Button from "../components/Button";
import Modal from "../components/Modal";
import { formatDate } from "../utils/formatDate";
import { formatTime } from "../utils/formatTime";

const EMPTY_FORM = { subject: "", faculty: "", semester: "", branch: "", date: "", startTime: "" };

const Sessions = () => {
    const { data: sessions, loading, error, setData } = useFetch(sessionService.getSessions, []);
    const { data: subjects } = useFetch(subjectService.getSubjects, []);

    const [modalOpen, setModalOpen] = useState(false);
    const [form, setForm] = useState(EMPTY_FORM);
    const [formError, setFormError] = useState("");
    const [submitting, setSubmitting] = useState(false);

    const onSubmit = async (e) => {
        e.preventDefault();
        setFormError("");
        setSubmitting(true);
        try {
            const payload = { ...form, semester: Number(form.semester) };
            const created = await sessionService.createSession(payload);
            setData((prev) => [created, ...(prev || [])]);
            setModalOpen(false);
            setForm(EMPTY_FORM);
        } catch (err) {
            setFormError(err?.response?.data?.message || "Could not create session.");
        } finally {
            setSubmitting(false);
        }
    };

    const columns = [
        { key: "subject", label: "Subject", render: (row) => row.subject?.name || row.subject?.code || "—" },
        { key: "faculty", label: "Faculty" },
        { key: "branch", label: "Branch" },
        { key: "semester", label: "Sem" },
        { key: "date", label: "Date", render: (row) => formatDate(row.date) },
        { key: "startTime", label: "Start", render: (row) => formatTime(row.startTime) },
        { key: "endTime", label: "End", render: (row) => formatTime(row.endTime) },
        {
            key: "status",
            label: "Status",
            render: (row) => (
                <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        row.status === "ACTIVE"
                            ? "bg-[var(--color-success)]/15 text-[var(--color-success)]"
                            : "bg-white/10 text-[var(--color-text-muted)]"
                    }`}
                >
                    {row.status}
                </span>
            ),
        },
    ];

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <h2 className="text-xl font-semibold text-[var(--color-text)]">Attendance Sessions</h2>
                    <p className="text-sm text-[var(--color-text-muted)]">
                        {sessions?.length ?? 0} sessions recorded
                    </p>
                </div>
                <Button onClick={() => setModalOpen(true)}>+ New Session</Button>
            </div>

            {error && (
                <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                    {error}
                </p>
            )}

            <Table columns={columns} data={sessions || []} loading={loading} emptyMessage="No sessions yet." />

            <Modal
                open={modalOpen}
                onClose={() => setModalOpen(false)}
                title="Start New Session"
                footer={
                    <>
                        <Button variant="secondary" onClick={() => setModalOpen(false)}>
                            Cancel
                        </Button>
                        <Button onClick={onSubmit} loading={submitting}>
                            Create Session
                        </Button>
                    </>
                }
            >
                <form onSubmit={onSubmit} className="space-y-3">
                    <Field label="Subject">
                        <select
                            required
                            value={form.subject}
                            onChange={(e) => setForm({ ...form, subject: e.target.value })}
                            className="input"
                        >
                            <option value="" disabled>
                                Select a subject
                            </option>
                            {(subjects || []).map((s) => (
                                <option key={s._id} value={s._id}>
                                    {s.code} — {s.name}
                                </option>
                            ))}
                        </select>
                    </Field>
                    <Field label="Faculty Name">
                        <input
                            required
                            value={form.faculty}
                            onChange={(e) => setForm({ ...form, faculty: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <div className="grid grid-cols-2 gap-3">
                        <Field label="Branch">
                            <input
                                required
                                value={form.branch}
                                onChange={(e) => setForm({ ...form, branch: e.target.value })}
                                className="input"
                            />
                        </Field>
                        <Field label="Semester">
                            <input
                                type="number"
                                min="1"
                                max="8"
                                required
                                value={form.semester}
                                onChange={(e) => setForm({ ...form, semester: e.target.value })}
                                className="input"
                            />
                        </Field>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <Field label="Date">
                            <input
                                type="date"
                                required
                                value={form.date}
                                onChange={(e) => setForm({ ...form, date: e.target.value })}
                                className="input"
                            />
                        </Field>
                        <Field label="Start Time">
                            <input
                                type="time"
                                required
                                value={form.startTime}
                                onChange={(e) => setForm({ ...form, startTime: e.target.value })}
                                className="input"
                            />
                        </Field>
                    </div>
                    {formError && (
                        <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                            {formError}
                        </p>
                    )}
                </form>
            </Modal>
        </div>
    );
};

const Field = ({ label, children }) => (
    <div>
        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">{label}</label>
        {children}
    </div>
);

export default Sessions;
