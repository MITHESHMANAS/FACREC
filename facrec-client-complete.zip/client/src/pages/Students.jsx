import { useMemo, useState } from "react";
import useFetch from "../hooks/useFetch";
import useAuth from "../hooks/useAuth";
import * as studentService from "../services/studentService";
import Table from "../components/Table";
import Button from "../components/Button";
import Modal from "../components/Modal";
import { downloadCSV } from "../utils/downloadPDF";

const EMPTY_FORM = { name: "", rollNo: "", email: "", branch: "", semester: "" };

const Students = () => {
    const { role } = useAuth();
    const isAdmin = role === "admin";
    const { data: students, loading, error, setData } = useFetch(studentService.getStudents, []);

    const [search, setSearch] = useState("");
    const [modalOpen, setModalOpen] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState(EMPTY_FORM);
    const [formError, setFormError] = useState("");
    const [submitting, setSubmitting] = useState(false);

    const filtered = useMemo(() => {
        const list = students || [];
        if (!search.trim()) return list;
        const q = search.toLowerCase();
        return list.filter(
            (s) =>
                s.name?.toLowerCase().includes(q) ||
                s.rollNo?.toLowerCase().includes(q) ||
                s.email?.toLowerCase().includes(q)
        );
    }, [students, search]);

    const openCreate = () => {
        setEditingId(null);
        setForm(EMPTY_FORM);
        setFormError("");
        setModalOpen(true);
    };

    const openEdit = (student) => {
        setEditingId(student._id);
        setForm({
            name: student.name,
            rollNo: student.rollNo,
            email: student.email,
            branch: student.branch,
            semester: student.semester,
        });
        setFormError("");
        setModalOpen(true);
    };

    const onDelete = async (student) => {
        if (!window.confirm(`Remove ${student.name}? This can't be undone.`)) return;
        try {
            await studentService.deleteStudent(student._id);
            setData((prev) => prev.filter((s) => s._id !== student._id));
        } catch (err) {
            alert(err?.response?.data?.message || "Could not delete student.");
        }
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        setFormError("");
        setSubmitting(true);
        try {
            const payload = { ...form, semester: Number(form.semester) };
            if (editingId) {
                const updated = await studentService.updateStudent(editingId, payload);
                setData((prev) => prev.map((s) => (s._id === editingId ? updated : s)));
            } else {
                const created = await studentService.createStudent(payload);
                setData((prev) => [created, ...(prev || [])]);
            }
            setModalOpen(false);
        } catch (err) {
            setFormError(err?.response?.data?.message || "Could not save student.");
        } finally {
            setSubmitting(false);
        }
    };

    const columns = [
        { key: "rollNo", label: "Roll No" },
        { key: "name", label: "Name" },
        { key: "email", label: "Email" },
        { key: "branch", label: "Branch" },
        { key: "semester", label: "Sem" },
        {
            key: "isActive",
            label: "Status",
            render: (row) => (
                <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        row.isActive
                            ? "bg-[var(--color-success)]/15 text-[var(--color-success)]"
                            : "bg-white/10 text-[var(--color-text-muted)]"
                    }`}
                >
                    {row.isActive ? "Active" : "Inactive"}
                </span>
            ),
        },
        ...(isAdmin
            ? [
                  {
                      key: "actions",
                      label: "",
                      render: (row) => (
                          <div className="flex gap-2">
                              <button
                                  onClick={() => openEdit(row)}
                                  className="text-xs font-medium text-[var(--color-accent)] hover:underline cursor-pointer"
                              >
                                  Edit
                              </button>
                              <button
                                  onClick={() => onDelete(row)}
                                  className="text-xs font-medium text-[var(--color-danger)] hover:underline cursor-pointer"
                              >
                                  Delete
                              </button>
                          </div>
                      ),
                  },
              ]
            : []),
    ];

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <h2 className="text-xl font-semibold text-[var(--color-text)]">Students</h2>
                    <p className="text-sm text-[var(--color-text-muted)]">
                        {students?.length ?? 0} enrolled students
                    </p>
                </div>
                <div className="flex gap-2">
                    <input
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder="Search by name, roll no, email…"
                        className="w-64 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2 text-sm text-[var(--color-text)] outline-none focus:border-[var(--color-accent)]"
                    />
                    <Button
                        variant="secondary"
                        onClick={() =>
                            downloadCSV({
                                filename: "students.csv",
                                columns: [
                                    { key: "rollNo", label: "Roll No" },
                                    { key: "name", label: "Name" },
                                    { key: "email", label: "Email" },
                                    { key: "branch", label: "Branch" },
                                    { key: "semester", label: "Semester" },
                                ],
                                rows: filtered,
                            })
                        }
                    >
                        Export CSV
                    </Button>
                    {isAdmin && <Button onClick={openCreate}>+ Add Student</Button>}
                </div>
            </div>

            {error && (
                <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                    {error}
                </p>
            )}

            <Table columns={columns} data={filtered} loading={loading} emptyMessage="No students found." />

            <Modal
                open={modalOpen}
                onClose={() => setModalOpen(false)}
                title={editingId ? "Edit Student" : "Add Student"}
                footer={
                    <>
                        <Button variant="secondary" onClick={() => setModalOpen(false)}>
                            Cancel
                        </Button>
                        <Button onClick={onSubmit} loading={submitting}>
                            {editingId ? "Save Changes" : "Add Student"}
                        </Button>
                    </>
                }
            >
                <form onSubmit={onSubmit} className="space-y-3">
                    <Field label="Full Name">
                        <input
                            required
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <Field label="Roll No">
                        <input
                            required
                            value={form.rollNo}
                            onChange={(e) => setForm({ ...form, rollNo: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <Field label="Email">
                        <input
                            type="email"
                            required
                            value={form.email}
                            onChange={(e) => setForm({ ...form, email: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <div className="grid grid-cols-2 gap-3">
                        <Field label="Branch">
                            <input
                                required
                                value={form.branch}
                                onChange={(e) => setForm({ ...form, branch: e.target.value })}
                                className="input"
                            />
                        </Field>
                        <Field label="Semester">
                            <input
                                type="number"
                                min="1"
                                max="8"
                                required
                                value={form.semester}
                                onChange={(e) => setForm({ ...form, semester: e.target.value })}
                                className="input"
                            />
                        </Field>
                    </div>
                    {formError && (
                        <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                            {formError}
                        </p>
                    )}
                </form>
            </Modal>
        </div>
    );
};

const Field = ({ label, children }) => (
    <div>
        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">{label}</label>
        {children}
    </div>
);

export default Students;
