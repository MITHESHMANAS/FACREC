import { useState } from "react";
import useFetch from "../hooks/useFetch";
import useAuth from "../hooks/useAuth";
import * as subjectService from "../services/subjectService";
import Table from "../components/Table";
import Button from "../components/Button";
import Modal from "../components/Modal";

const EMPTY_FORM = { code: "", name: "", semester: "", branch: "", faculty: "" };

const Subjects = () => {
    const { role } = useAuth();
    const isAdmin = role === "admin";
    const { data: subjects, loading, error, setData } = useFetch(subjectService.getSubjects, []);

    const [modalOpen, setModalOpen] = useState(false);
    const [form, setForm] = useState(EMPTY_FORM);
    const [formError, setFormError] = useState("");
    const [submitting, setSubmitting] = useState(false);

    const onSubmit = async (e) => {
        e.preventDefault();
        setFormError("");
        setSubmitting(true);
        try {
            const payload = { ...form, semester: Number(form.semester) };
            const created = await subjectService.createSubject(payload);
            setData((prev) => [created, ...(prev || [])]);
            setModalOpen(false);
            setForm(EMPTY_FORM);
        } catch (err) {
            setFormError(err?.response?.data?.message || "Could not save subject.");
        } finally {
            setSubmitting(false);
        }
    };

    const columns = [
        { key: "code", label: "Code" },
        { key: "name", label: "Subject" },
        { key: "branch", label: "Branch" },
        { key: "semester", label: "Sem" },
        { key: "faculty", label: "Faculty" },
        {
            key: "isActive",
            label: "Status",
            render: (row) => (
                <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        row.isActive
                            ? "bg-[var(--color-success)]/15 text-[var(--color-success)]"
                            : "bg-white/10 text-[var(--color-text-muted)]"
                    }`}
                >
                    {row.isActive ? "Active" : "Inactive"}
                </span>
            ),
        },
    ];

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <h2 className="text-xl font-semibold text-[var(--color-text)]">Subjects</h2>
                    <p className="text-sm text-[var(--color-text-muted)]">
                        {subjects?.length ?? 0} subjects across all branches
                    </p>
                </div>
                {isAdmin && <Button onClick={() => setModalOpen(true)}>+ Add Subject</Button>}
            </div>

            {error && (
                <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                    {error}
                </p>
            )}

            <Table columns={columns} data={subjects || []} loading={loading} emptyMessage="No subjects found." />

            <Modal
                open={modalOpen}
                onClose={() => setModalOpen(false)}
                title="Add Subject"
                footer={
                    <>
                        <Button variant="secondary" onClick={() => setModalOpen(false)}>
                            Cancel
                        </Button>
                        <Button onClick={onSubmit} loading={submitting}>
                            Add Subject
                        </Button>
                    </>
                }
            >
                <form onSubmit={onSubmit} className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                        <Field label="Code">
                            <input
                                required
                                value={form.code}
                                onChange={(e) => setForm({ ...form, code: e.target.value })}
                                className="input"
                                placeholder="CS301"
                            />
                        </Field>
                        <Field label="Semester">
                            <input
                                type="number"
                                min="1"
                                max="8"
                                required
                                value={form.semester}
                                onChange={(e) => setForm({ ...form, semester: e.target.value })}
                                className="input"
                            />
                        </Field>
                    </div>
                    <Field label="Subject Name">
                        <input
                            required
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <Field label="Branch">
                        <input
                            required
                            value={form.branch}
                            onChange={(e) => setForm({ ...form, branch: e.target.value })}
                            className="input"
                        />
                    </Field>
                    <Field label="Faculty">
                        <input
                            value={form.faculty}
                            onChange={(e) => setForm({ ...form, faculty: e.target.value })}
                            className="input"
                            placeholder="Not Assigned"
                        />
                    </Field>
                    {formError && (
                        <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                            {formError}
                        </p>
                    )}
                </form>
            </Modal>
        </div>
    );
};

const Field = ({ label, children }) => (
    <div>
        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">{label}</label>
        {children}
    </div>
);

export default Subjects;
