import { useState } from "react";
import useAttendance from "../hooks/useAttendance";
import useFetch from "../hooks/useFetch";
import * as sessionService from "../services/sessionService";
import * as studentService from "../services/studentService";
import Table from "../components/Table";
import Button from "../components/Button";
import Modal from "../components/Modal";
import { formatDate } from "../utils/formatDate";
import { downloadPDF } from "../utils/downloadPDF";

const EMPTY_FORM = { student: "", session: "", status: "Present" };

const Attendance = () => {
    const { attendance, loading, error, mark, marking, markError } = useAttendance();
    const { data: sessions } = useFetch(sessionService.getSessions, []);
    const { data: students } = useFetch(studentService.getStudents, []);

    const [modalOpen, setModalOpen] = useState(false);
    const [form, setForm] = useState(EMPTY_FORM);

    const onSubmit = async (e) => {
        e.preventDefault();
        try {
            await mark(form);
            setModalOpen(false);
            setForm(EMPTY_FORM);
        } catch {
            // markError already surfaced via the hook
        }
    };

    const columns = [
        { key: "student", label: "Student", render: (row) => row.student?.name || row.student?.rollNo || "—" },
        {
            key: "session",
            label: "Subject",
            render: (row) => row.session?.subject?.name || row.session?.subject?.code || "—",
        },
        {
            key: "status",
            label: "Status",
            render: (row) => (
                <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        row.status === "Present"
                            ? "bg-[var(--color-success)]/15 text-[var(--color-success)]"
                            : "bg-[var(--color-danger)]/15 text-[var(--color-danger)]"
                    }`}
                >
                    {row.status}
                </span>
            ),
        },
        { key: "markedAt", label: "Marked At", render: (row) => formatDate(row.markedAt) },
    ];

    const exportReport = () => {
        downloadPDF({
            title: "Attendance Report",
            columns: [
                { key: "studentName", label: "Student" },
                { key: "status", label: "Status" },
                { key: "markedAt", label: "Date" },
            ],
            rows: attendance.map((row) => ({
                studentName: row.student?.name || row.student?.rollNo || "—",
                status: row.status,
                markedAt: formatDate(row.markedAt),
            })),
        });
    };

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <h2 className="text-xl font-semibold text-[var(--color-text)]">Attendance</h2>
                    <p className="text-sm text-[var(--color-text-muted)]">
                        {attendance.length} records logged
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button variant="secondary" onClick={exportReport}>
                        Export PDF
                    </Button>
                    <Button onClick={() => setModalOpen(true)}>+ Mark Attendance</Button>
                </div>
            </div>

            {error && (
                <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                    {error}
                </p>
            )}

            <Table columns={columns} data={attendance} loading={loading} emptyMessage="No attendance marked yet." />

            <Modal
                open={modalOpen}
                onClose={() => setModalOpen(false)}
                title="Mark Attendance"
                footer={
                    <>
                        <Button variant="secondary" onClick={() => setModalOpen(false)}>
                            Cancel
                        </Button>
                        <Button onClick={onSubmit} loading={marking}>
                            Mark Attendance
                        </Button>
                    </>
                }
            >
                <form onSubmit={onSubmit} className="space-y-3">
                    <Field label="Session">
                        <select
                            required
                            value={form.session}
                            onChange={(e) => setForm({ ...form, session: e.target.value })}
                            className="input"
                        >
                            <option value="" disabled>
                                Select a session
                            </option>
                            {(sessions || []).map((s) => (
                                <option key={s._id} value={s._id}>
                                    {(s.subject?.name || s.subject?.code || "Session")} — {formatDate(s.date)}
                                </option>
                            ))}
                        </select>
                    </Field>
                    <Field label="Student">
                        <select
                            required
                            value={form.student}
                            onChange={(e) => setForm({ ...form, student: e.target.value })}
                            className="input"
                        >
                            <option value="" disabled>
                                Select a student
                            </option>
                            {(students || []).map((s) => (
                                <option key={s._id} value={s._id}>
                                    {s.rollNo} — {s.name}
                                </option>
                            ))}
                        </select>
                    </Field>
                    <Field label="Status">
                        <select
                            value={form.status}
                            onChange={(e) => setForm({ ...form, status: e.target.value })}
                            className="input"
                        >
                            <option value="Present">Present</option>
                            <option value="Absent">Absent</option>
                        </select>
                    </Field>
                    {markError && (
                        <p className="rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/10 px-3 py-2 text-xs text-[var(--color-danger)]">
                            {markError}
                        </p>
                    )}
                </form>
            </Modal>
        </div>
    );
};

const Field = ({ label, children }) => (
    <div>
        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">{label}</label>
        {children}
    </div>
);

export default Attendance;
